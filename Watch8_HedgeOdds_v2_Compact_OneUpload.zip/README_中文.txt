Watch8 赔率保本计算器 v2 · 首页紧凑布局
=====================================

这个版本基于上传的 Watch8_HedgeOdds_v1_OneUpload.zip 修改。

1. 主要调整（不改动 HedgeMath 原版 v3.3 算法）
   · 首屏显示“两张单 / 三张单”以及“保本 / 均衡 / 手动”。
   · 两张单：四个输入框，按两列成对显示。
   · 三张单：六个输入框，按两列、三行显示，不需向下滑动找输入框。
   · 第一屏下方显示简短建议及状态；向上滑动进入第二屏区域看完整结算。
   · 详细结果保留：建议金额、保本区间/配对、均衡金额/配对、
     两/三种比分净盈亏、其他比分净损失、三单赔付覆盖情况。
   · 设置与说明内容在下面，可以自由继续下滑阅读。
   · 点击任何一个输入框进入原生数字键盘，标题、数值显示、
     0-9、小数点、退格、清空和“完成 ✓”尽量完整显示在同一屏。
   · 横向间距按圆形屏幕高度变化，防止边缘文字被表盘切掉。
   · 纯黑背景，离线运行，不弹系统数字键盘。

2. 保留原有功能
   · 原始 HedgeMath.java 文件完全未修改。
   · 原本的金额和赔率持久保存、切换两/三单时重置至保本模式、
     手动编辑保险金额自动进入手动模式、返回键提交数字等行为均保留。
   · 同包名 com.hthedge.watch8，升级安装可继续沿用旧输入数据。
   · 仍然是手表独立 Wear OS 应用，不需要手机配套 APP。

3. GitHub Actions 编译（推荐新仓库名 Watch8-HedgeOdds-Compact-v2）
   · 新建一个空的 GitHub 仓库。
   · 上传 Watch8_HedgeOdds_v2_Compact_OneUpload.zip 到仓库根目录，
     不用解压。
   · 在仓库新建 .github/workflows/build-apk.yml 文件，
     将附带的 Watch8_HedgeOdds_v2_build-apk.yml 内容全部粘贴进去。
   · 进入 Actions → Build Watch8 Hedge Odds Compact APK → Run workflow。
   · 在成功的运行页下载 Watch8-HedgeOdds-v2-Compact-APK。
   · 解压 Actions 下载的 artifact，得到 app-debug.apk，再安装到手表。

4. 注意
   · 已通过原版 HedgeMath v3.3 回归测试。
   · 这里提供修改后的源码及 GitHub Actions 构建文件；当前本地环境
     没有 Android SDK/Gradle，未在本机编译安装 APK。构建成功以 Actions 为准。
   · 小屏幕首屏紧凑显示依赖手表实际 DPI/字体缩放；如有自定义超大字体，
     部分极长的数值会自动缩小。下翻区域有完整计算文本。
   · 只计算所列互斥结果的账面盈亏，非保证盈利；另有赔率波动、
     平台手续费、下注限制等风险。
